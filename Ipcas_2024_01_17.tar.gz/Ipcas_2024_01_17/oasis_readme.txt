Compile the oasis file manually, please run the command as follw:
Ubuntu:
cd src
sudo apt-get install gcc-5 libstdc++-5-dev
make Linux (Linux system)

Mac:
cd src
make Darwin (Mac system)
(optional)

